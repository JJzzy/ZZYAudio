//
//  UVAudioUnitManager.m
//
//
//  Created by zzy on 2018/10/25.
//  Copyright © 2018年. All rights reserved.
//

#import "UVAudioUnitManager.h"
#import <AVFoundation/AVFoundation.h>

#define INPUT_BUS   1
#define OUTPUT_BUS  0
#define kSampleRate 8000 //采样率
#define DATA_LENGTH 640 //设备侧获取音频接口每次需要的数据长度

static AudioBufferList _recordBufferList;//音频采集数据
static AudioUnit _audioUnit;

static NSMutableData *_recordPcmData;//客户端采集的音频数据，发送到设备侧
static NSMutableData *_receivePcmData;//客户端从设备侧获取的音频数据

@interface UVAudioUnitManager ()

@property (assign, nonatomic) BOOL isUnitWorking;//语音对讲状态标志位
@property (assign, nonatomic) BOOL isRecording;  //音频采集（录音）是否开启状态
@property (assign, nonatomic) BOOL isPlaying;    //音频播放状态
@property (assign, nonatomic) int currentRate;    //音频播放状态

@end

@implementation UVAudioUnitManager

static UVAudioUnitManager *sharedInstace = nil;
+ (instancetype)sharedInstance {
    if (!sharedInstace) {
        sharedInstace = [[UVAudioUnitManager alloc] init];
        [sharedInstace initRemoteIO];
    }
    return sharedInstace;
}

- (void)initRemoteIO {
    //初始化_audioUnit
    AudioUnitInitialize(_audioUnit);
//    //语音对讲中断通知
//    [UVNotiCenter addObserver:sharedInstace selector:@selector(handleAudioSessionInterruptionNoti:) name:AVAudioSessionInterruptionNotification object:nil];
    [sharedInstace initBuffer];
    [sharedInstace initAudioComponent];
    [sharedInstace initFormat];
    [sharedInstace initAudioProperty];
    [sharedInstace initRecordeCallback];
    [sharedInstace initPlayCallback];
}
////语音对讲中断通知
//- (void)handleAudioSessionInterruptionNoti:(NSNotification *)noti
//{
//    [[UVVoiceIntercomManager sharedInstance] closeCurrentVoiceIntercomState];
//}

//采集音频数据时，使用自定义的全局变量_recordBufferList，而不使用系统的ioData数据，因此需要这里的操作
- (void)initBuffer {
    UInt32 flag = 0;
    AudioUnitSetProperty(_audioUnit,
                         kAudioUnitProperty_ShouldAllocateBuffer,
                         kAudioUnitScope_Output,
                         INPUT_BUS,
                         &flag,
                         sizeof(flag));
}

//初始化配置组件
- (void)initAudioComponent {
    AudioComponentDescription audioDesc;
    audioDesc.componentType = kAudioUnitType_Output;
    audioDesc.componentSubType = kAudioUnitSubType_VoiceProcessingIO;
    audioDesc.componentManufacturer = kAudioUnitManufacturer_Apple;
    audioDesc.componentFlags = 0;
    audioDesc.componentFlagsMask = 0;
    
    AudioComponent inputComponent = AudioComponentFindNext(NULL, &audioDesc);
    AudioComponentInstanceNew(inputComponent, &_audioUnit);
}

//初始化赋值音频输入、输出的各项参数、属性
- (void)initFormat {
    //设置音频参数
    [self initFormatWithRate:kSampleRate];
}
- (void)initFormatWithRate:(int)rate {
    //设置音频参数
    AudioStreamBasicDescription audioFormat;
    audioFormat.mSampleRate = rate;//采样率
    self.currentRate = rate;
    audioFormat.mFormatID = kAudioFormatLinearPCM;
    audioFormat.mFormatFlags = kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked;
    audioFormat.mFramesPerPacket = 1;//每一个packet一侦数据
    audioFormat.mChannelsPerFrame = 1;//单声道
    audioFormat.mBitsPerChannel = 16;//每个采样点16bit量化
    audioFormat.mBytesPerPacket = 2;
    audioFormat.mBytesPerFrame = 2;
    
    AudioUnitSetProperty(_audioUnit,
                         kAudioUnitProperty_StreamFormat,
                         kAudioUnitScope_Input,
                         OUTPUT_BUS,
                         &audioFormat,
                         sizeof(audioFormat));
    AudioUnitSetProperty(_audioUnit,
                         kAudioUnitProperty_StreamFormat,
                         kAudioUnitScope_Output,
                         INPUT_BUS,
                         &audioFormat,
                         sizeof(audioFormat));
}

//初始化音频输入、输出功能
- (void)initAudioProperty {
    UInt32 flag = 1;
    //初始化音频输入功能
    AudioUnitSetProperty(_audioUnit,
                         kAudioOutputUnitProperty_EnableIO,
                         kAudioUnitScope_Input,
                         INPUT_BUS,
                         &flag,
                         sizeof(flag));
    
    //第四个参数默认时0，表示从App到扬声器的IO是打开的；而1，表示从麦克风到App的IO是打开的。这里是音频输出，所以使用OUTPUT_BUS
    AudioUnitSetProperty(_audioUnit,
                         kAudioOutputUnitProperty_EnableIO,
                         kAudioUnitScope_Output,
                         OUTPUT_BUS,
                         &flag,
                         sizeof(flag));
}

//初始化音频采集回调函数（将本地采集的数据将发送到B端）
- (void)initRecordeCallback {
    AURenderCallbackStruct recordCallback;
    recordCallback.inputProc = RecordCallback;
    recordCallback.inputProcRefCon = (__bridge void *)sharedInstace;
    AudioUnitSetProperty(_audioUnit,
                         kAudioOutputUnitProperty_SetInputCallback,
                         kAudioUnitScope_Global,
                         INPUT_BUS,
                         &recordCallback,
                         sizeof(recordCallback));
}

//初始化音频播放回调函数（播放从B端传来的数据）
- (void)initPlayCallback {
    AURenderCallbackStruct playCallback;
    playCallback.inputProc = PlayCallback;
    playCallback.inputProcRefCon = (__bridge void *)sharedInstace;
    AudioUnitSetProperty(_audioUnit,
                         kAudioUnitProperty_SetRenderCallback,
                         kAudioUnitScope_Global,
                         OUTPUT_BUS,
                         &playCallback,
                         sizeof(playCallback));
}

#pragma mark - callback function
//采集客户端音频数据传输回调，并将数据返回给另外一端(即B端)
static OSStatus RecordCallback(void *inRefCon,
                               AudioUnitRenderActionFlags *ioActionFlags,
                               const AudioTimeStamp *inTimeStamp,
                               UInt32 inBusNumber,
                               UInt32 inNumberFrames,
                               AudioBufferList *ioData) {
    
    if (sharedInstace.isRecording) {//需要采集音频
        //初始化采样数据的buffer
        UInt32 numSamples = inNumberFrames * 1;
        UInt32 samples[numSamples];
        memset (&samples, 0, sizeof (samples));
        _recordBufferList.mNumberBuffers = 1;
        _recordBufferList.mBuffers[0].mData = samples;
        _recordBufferList.mBuffers[0].mNumberChannels = 1;
        _recordBufferList.mBuffers[0].mDataByteSize = numSamples * sizeof(UInt32);
        //获取采样数据，并保存在_recordBufferList中的buffers
        AudioUnitRender(_audioUnit, ioActionFlags, inTimeStamp, inBusNumber, inNumberFrames, &_recordBufferList);
        
        NSData *pcmData = [NSData dataWithBytes:_recordBufferList.mBuffers[0].mData length:_recordBufferList.mBuffers[0].mDataByteSize];
        //缓存采集的音频数据。由于回调每次采集的pcmData长度为370左右，而如果接受本地采集数据的另外一端B的接受长度不为370，就需要在这里进行缓存，因此需要将采集的音频数据进行缓存，达到B段数据长度要求时在返回给B段
        [_recordPcmData appendData:pcmData];
        NSLog(@"zzy:recordPcmData.length=====================>%ld,%ld", (unsigned long)pcmData.length, (unsigned long)_recordPcmData.length);
        if (_recordPcmData.length >= DATA_LENGTH) {
            NSData *data = [_recordPcmData subdataWithRange:NSMakeRange(0, DATA_LENGTH)];
            Byte *audioData = (Byte *)data.bytes;
            INT32 pcmLen = (int)data.length;
            if((audioData != NULL) && pcmLen > 0){
                /**
                 在这里将采集到的数据audioData，并截取长度pcmLen，返回给B端，去进行播放
                 
                 ........
                 
                 */
                [_recordPcmData replaceBytesInRange:NSMakeRange(0, DATA_LENGTH) withBytes:NULL length:0];//已发送到设备侧的数据从缓存中删除
            }
        }
    }
    return noErr;
}

//在客户端播放设备侧(即B端)音频的数据回调
static OSStatus PlayCallback(void *inRefCon,
                             AudioUnitRenderActionFlags *ioActionFlags,
                             const AudioTimeStamp *inTimeStamp,
                             UInt32 inBusNumber,
                             UInt32 inNumberFrames,
                             AudioBufferList *ioData) {
    if (sharedInstace.isPlaying) {//播放开关开启
        UInt32 buffLen = ioData->mBuffers[0].mDataByteSize;
        NSLog(@"zzy:PlayCallback.length------------>%d,%ld", (unsigned int)buffLen, (unsigned long)_receivePcmData.length);
        if (_receivePcmData.length >= buffLen) {//音频数据长度必须大于系统播放所需的大小才能够正常播放音频
            NSData *data = [_receivePcmData subdataWithRange:NSMakeRange(0, buffLen)];
            AudioBuffer inBuffer = ioData->mBuffers[0];
            memcpy(inBuffer.mData, data.bytes, data.length);
            inBuffer.mDataByteSize = (UInt32)data.length;
            [_receivePcmData replaceBytesInRange:NSMakeRange(0, buffLen) withBytes:NULL length:0];//已播放的音频数据从缓存中删除
        } else {
            NSLog(@"zzy:PlayCallBack.静音------------>%ld", (unsigned long)_receivePcmData.length);
            for (UInt32 i = 0; i < ioData->mNumberBuffers; i++) {
                memset(ioData->mBuffers[i].mData, 0, ioData->mBuffers[i].mDataByteSize);
            }
        }
    } else {
        NSLog(@"zzy:PlayCallBack.静音------------>%ld", (unsigned long)_receivePcmData.length);
        for (UInt32 i = 0; i < ioData->mNumberBuffers; i++) {
            memset(ioData->mBuffers[i].mData, 0, ioData->mBuffers[i].mDataByteSize);
        }
    }
    return noErr;
}
- (void)resetRateWithWaveFrameType:(int)waveFrameType {
    //获取采样率
    int rate = 1000;
    switch (waveFrameType) {
        case 0://8K
        {
            rate *= 8;
            break;
        }
        case 1://16K
        {
            rate *= 16;
            break;
        }
        case 2://44.1k
        {
            rate *= 44.1;
            break;
        }
        case 3://11.025K
        {
            rate *= 11.025;
            break;
        }
        case 6://48K
        {
            rate *= 48;
            break;
        }
        default://UNKNOWN
        {
            rate *= 8;
            break;
        }
    }
    
    if (self.currentRate == rate) {
        return;
    }
    
    [self initFormatWithRate:rate];
}
//接收来自设备的音频数据流，缓存在_receivePcmData中，用于PlayCallback播放音频回调
- (void)play:(void*)pcmData length:(unsigned int)length waveFrameType:(int)waveFrameType{
    
    [self resetRateWithWaveFrameType:waveFrameType];
    
    //语音对讲开启时，会持续调用此方法，若音频中断则重新开启音频
    if (!sharedInstace.isUnitWorking && sharedInstace.isPlaying && sharedInstace.isRecording) {
        [sharedInstace startRecordAndPlay];
    }
    
    /*
     1、经过测试，网络正常情况下，1s内可获取的数据长度为16000左右，而播放音频的回调1s播放的数据长度也在16000左右;
     2、网络异常时，_receivePcmData可能会不断增长变大，进而占用更多内存、增大设备侧和客户端音频的延迟。因此，需要对_receivePcmData大小进行限制，此处大小上限暂定为16000，当大于此数值时，丢弃前一半的数据，但同时降低了客户端的延迟（延迟在1s内）。
     */
    int limitLength = 16000;
    if (_receivePcmData.length >= limitLength) {
        //避免缓存数据过大，丢弃一部分数据(只有网络异常时才可能出现此种情况)
        [_receivePcmData replaceBytesInRange:NSMakeRange(0, limitLength/2) withBytes:NULL length:0];
    }
    //缓存数据
    [_receivePcmData appendData:[NSData dataWithBytes:(Byte *)pcmData length:length].mutableCopy];
    
    //设置扬声器模式前，判断是否有耳机插入
    UInt32 audioRouteOverride;
    AVAudioSessionRouteDescription *currentRoute = [[AVAudioSession sharedInstance] currentRoute];
    for (AVAudioSessionPortDescription *output in currentRoute.outputs) {
        if ([[output portType] isEqualToString:AVAudioSessionPortHeadphones]) {
            audioRouteOverride = kAudioSessionOverrideAudioRoute_None;
        }else {
            audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;  //设置成扬声器模式
        }
    }
    AudioSessionSetProperty(kAudioSessionProperty_OverrideAudioRoute, sizeof(audioRouteOverride), &audioRouteOverride);
}

- (void)initAudioSession {
    
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];//支持播放和录音
    [audioSession setActive:YES error:nil];
    
    //设置扬声器模式前，判断是否有耳机插入
    UInt32 audioRouteOverride;
    AVAudioSessionRouteDescription *currentRoute = [audioSession currentRoute];
    for (AVAudioSessionPortDescription *output in currentRoute.outputs) {
        if ([[output portType] isEqualToString:AVAudioSessionPortHeadphones]) {
            audioRouteOverride = kAudioSessionOverrideAudioRoute_None;
        }else {
            audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;  //设置成扬声器模式
        }
    }
    AudioSessionSetProperty(kAudioSessionProperty_OverrideAudioRoute, sizeof(audioRouteOverride), &audioRouteOverride);
    
    //VoiceProcessingIO有一个属性可用来打开(0)/关闭(1)回声消除功能
    UInt32 echoCancellation = 0;
    AudioUnitSetProperty(_audioUnit,
                         kAUVoiceIOProperty_BypassVoiceProcessing,
                         kAudioUnitScope_Global,
                         0,
                         &echoCancellation,
                         sizeof(echoCancellation));
    
    AudioOutputUnitStart(_audioUnit);
    sharedInstace.isUnitWorking = YES;
}

#pragma mark - public methods
//开始采集音频数据
- (void)startRecord {
    UVILog(@"zzy:开始采集音频数据");
    _recordPcmData = nil;
    _recordPcmData = [NSMutableData data];
    sharedInstace.isRecording = YES;
}
//停止采集音频数据
- (void)stopRecord {
    UVILog(@"zzy:停止采集音频数据");
    sharedInstace.isRecording = NO;
}
//开始播放音频
- (void)startPlay {
    UVILog(@"zzy:开始播放音频");
    _receivePcmData = nil;
    _receivePcmData = [NSMutableData data];
    [sharedInstace initAudioSession];
    sharedInstace.isPlaying = YES;
}
//停止播放音频
- (void)stopPlay {
    if (sharedInstace.isRecording && sharedInstace.isPlaying) {
        UVILog(@"zzy:同时开启了录音和播放，即正在语音对讲中...");
        return;
    }
    UVILog(@"zzy:停止播放音频");
    AudioOutputUnitStop(_audioUnit);
    sharedInstace.isUnitWorking = NO;
    sharedInstace.isPlaying = NO;
    //将音频模式设置为播放，否则会导致其他功能播放声音会变小（例如：本地录像音频）
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    [audioSession setCategory:AVAudioSessionCategoryPlayback error:nil];
    [audioSession setActive:YES error:nil];
}

- (void)startRecordAndPlay {
    if (sharedInstace.isUnitWorking) {
        UVILog(@"zzy:正在语音对讲中...");
        return;
    }
    UVILog(@"zzy:开始语音对讲");
    [sharedInstace startRecord];
    [sharedInstace startPlay];
}

- (void)stopRecordAndPlay {
    UVILog(@"zzy:结束语音对讲");
    //以下两个方法的调用顺序不能颠倒
    [sharedInstace stopRecord];
    [sharedInstace stopPlay];
    
    [sharedInstace audio_release];
    sharedInstace = nil;
}

- (void)audio_release {
    AudioUnitUninitialize(_audioUnit);
    AudioComponentInstanceDispose(_audioUnit);
    _audioUnit = nil;
}

@end

