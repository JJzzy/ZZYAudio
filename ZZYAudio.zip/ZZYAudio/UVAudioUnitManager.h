//
//  UVAudioUnitManager.h
//  EZViewer
//
//  Created by zzy on 2018/10/25.
//  Copyright © 2018年 uniview. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UVAudioUnitManager : NSObject

+ (instancetype)sharedInstance;

/**
 开始语音对讲
 */
- (void)startRecordAndPlay;

/**
 停止语音对讲
 */
- (void)stopRecordAndPlay;

//播放音频数据
- (void)play:(void*)pcmData length:(unsigned int)length waveFrameType:(int)waveFrameType;
@end
